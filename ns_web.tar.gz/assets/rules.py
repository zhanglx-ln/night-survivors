"""Night Survivors: the game rules.

This file has no pygame in it. That means we can test the rules quickly,
and the same rules can run in a browser.

Step 1 (Core) has:
    - the hero, moving in any direction
    - Bats that chase the hero
    - the spawning rules (every 1 s, at most 8 new Bats, 380 px away)
    - contact damage (at most once every 0.5 s per enemy)
    - the Spark Wand (level 1)
    - HP, GAME OVER and play again

Gems, XP and level-up come in step 3. The other enemies, the boss and
VICTORY come in step 4.
"""

import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

# The game always moves in steps of 1/60 of a second.
DT = 1.0 / 60.0

DATA_FILE = Path(__file__).resolve().parent / "data" / "game.json"


def load_data(path=DATA_FILE):
    """Read all the numbers from data/game.json."""
    with open(path, encoding="utf-8") as file:
        return json.load(file)


@dataclass
class Hero:
    x: float
    y: float
    hp: int
    max_hp: int
    speed: float
    hit_radius: float


@dataclass
class Enemy:
    kind: str
    x: float
    y: float
    hp: int
    speed: float
    damage: int
    xp: int
    radius: float
    # The last time (game seconds) this enemy hurt the hero.
    # A very old time means "has not hurt the hero yet".
    last_hit_time: float = -1_000_000.0


@dataclass
class Spark:
    x: float
    y: float
    vx: float
    vy: float
    damage: int
    radius: float
    life: float


class Game:
    """The whole game state. main.py draws it; tests check it."""

    def __init__(self, data=None, seed=None):
        self.data = data if data is not None else load_data()
        self.rng = random.Random(seed)
        self.reset()

    # ------------------------------------------------------------------
    # Starting and restarting
    # ------------------------------------------------------------------
    def reset(self):
        """Start again from the beginning (also used by 'play again')."""
        hero_cfg = self.data["hero"]
        self.hero = Hero(
            x=0.0,
            y=0.0,
            hp=hero_cfg["max_hp"],
            max_hp=hero_cfg["max_hp"],
            speed=hero_cfg["speed"],
            hit_radius=hero_cfg["hit_radius"],
        )
        self.enemies = []
        self.sparks = []
        self.time = 0.0
        self.kills = 0
        self.state = "playing"  # "playing" or "game_over"
        self.weapons = {"spark_wand": 1}
        self.spark_timer = 0.0
        self.spawn_timer = 0.0
        # Fill the world once at the start, so the first Bats are there.
        self._spawn_wave()

    # ------------------------------------------------------------------
    # One fixed step of the game
    # ------------------------------------------------------------------
    def step(self, dt=DT, move=(0.0, 0.0)):
        """Move the game forward by dt seconds.

        `move` is a direction like (1, 0) or (0.3, -0.9). It does not
        need to be a unit vector; we normalise it here, so a diagonal
        walk is not faster than a straight walk.
        """
        if self.state != "playing":
            return

        self.time += dt
        self._move_hero(dt, move)
        self._move_enemies(dt)
        self._contact_damage()
        self._update_sparks(dt)
        self._fire_spark(dt)
        self._update_spawning(dt)
        self._remove_far_enemies()

        if self.hero.hp <= 0:
            self.hero.hp = 0
            self.state = "game_over"

    def _move_hero(self, dt, move):
        mx, my = move
        length = math.hypot(mx, my)
        if length > 0.0001:
            self.hero.x += (mx / length) * self.hero.speed * dt
            self.hero.y += (my / length) * self.hero.speed * dt

    def _move_enemies(self, dt):
        for enemy in self.enemies:
            dx = self.hero.x - enemy.x
            dy = self.hero.y - enemy.y
            distance = math.hypot(dx, dy)
            if distance > 0.0001:
                enemy.x += (dx / distance) * enemy.speed * dt
                enemy.y += (dy / distance) * enemy.speed * dt

    # ------------------------------------------------------------------
    # Getting hurt
    # ------------------------------------------------------------------
    def _contact_damage(self):
        interval = self.data["contact_damage_interval"]
        for enemy in self.enemies:
            reach = self.hero.hit_radius + enemy.radius
            if _distance(self.hero, enemy) > reach:
                continue
            if self.time - enemy.last_hit_time < interval:
                continue
            enemy.last_hit_time = self.time
            self.hero.hp -= enemy.damage

    # ------------------------------------------------------------------
    # Spark Wand
    # ------------------------------------------------------------------
    def _fire_spark(self, dt):
        weapon = self.data["weapons"]["spark_wand"]
        stats = weapon["level1"]
        if not self.enemies:
            return

        # Only count down while there is something to shoot at.
        self.spark_timer = max(0.0, self.spark_timer - dt)
        if self.spark_timer > 0:
            return

        target = self.nearest_enemy()
        if target is None:
            return

        dx = target.x - self.hero.x
        dy = target.y - self.hero.y
        distance = math.hypot(dx, dy)
        if distance < 0.0001:
            return
        dx /= distance
        dy /= distance

        for index in range(stats["sparks"]):
            # With more than one spark (level 3 and 5) they fan out a bit.
            spread = 0.0
            if stats["sparks"] > 1:
                spread = math.radians(10) * (index - (stats["sparks"] - 1) / 2)
            cos_a = math.cos(spread)
            sin_a = math.sin(spread)
            vx = (dx * cos_a - dy * sin_a) * stats["speed"]
            vy = (dx * sin_a + dy * cos_a) * stats["speed"]
            self.sparks.append(
                Spark(
                    x=self.hero.x,
                    y=self.hero.y,
                    vx=vx,
                    vy=vy,
                    damage=stats["damage"],
                    radius=weapon["spark_radius"],
                    life=weapon["spark_lifetime"],
                )
            )
        self.spark_timer = stats["cooldown"]

    def nearest_enemy(self):
        """The enemy closest to the hero, or None."""
        nearest = None
        best = None
        for enemy in self.enemies:
            distance = _distance_sq(self.hero, enemy)
            if best is None or distance < best:
                best = distance
                nearest = enemy
        return nearest

    def _update_sparks(self, dt):
        alive = []
        for spark in self.sparks:
            spark.x += spark.vx * dt
            spark.y += spark.vy * dt
            spark.life -= dt
            if spark.life <= 0:
                continue

            hit_enemy = None
            for enemy in self.enemies:
                reach = spark.radius + enemy.radius
                if _distance(spark, enemy) <= reach:
                    hit_enemy = enemy
                    break

            if hit_enemy is None:
                alive.append(spark)
                continue

            hit_enemy.hp -= spark.damage
            if hit_enemy.hp <= 0:
                self.enemies.remove(hit_enemy)
                self.kills += 1
            # A spark disappears when it hits one enemy.
        self.sparks = alive

    # ------------------------------------------------------------------
    # Spawning
    # ------------------------------------------------------------------
    def minimum_alive(self):
        """How many enemies should be alive right now.

        Step 1 uses one fixed number for Bats. In step 4 this will read
        the `waves` table in data/game.json.
        """
        return self.data["spawning"]["minimum_alive"]

    def _update_spawning(self, dt):
        cfg = self.data["spawning"]
        self.spawn_timer += dt
        while self.spawn_timer >= cfg["check_interval"]:
            self.spawn_timer -= cfg["check_interval"]
            self._spawn_wave()

    def _spawn_wave(self):
        cfg = self.data["spawning"]
        room = cfg["max_alive"] - len(self.enemies)
        need = self.minimum_alive() - len(self.enemies)
        need = min(need, cfg["max_per_check"], room)
        for _ in range(max(0, need)):
            kind = self.rng.choice(cfg["spawn_types"])
            self.spawn_enemy(kind)

    def spawn_enemy(self, kind, distance=None):
        """Put one enemy on the spawn circle around the hero."""
        cfg = self.data["enemies"][kind]
        if distance is None:
            distance = self.data["spawning"]["spawn_radius"]
        angle = self.rng.uniform(0.0, math.tau)
        enemy = Enemy(
            kind=kind,
            x=self.hero.x + math.cos(angle) * distance,
            y=self.hero.y + math.sin(angle) * distance,
            hp=cfg["hp"],
            speed=cfg["speed"],
            damage=cfg["damage"],
            xp=cfg["xp"],
            radius=cfg["radius"],
        )
        self.enemies.append(enemy)
        return enemy

    def _remove_far_enemies(self):
        limit = self.data["spawning"]["remove_distance"]
        self.enemies = [
            enemy
            for enemy in self.enemies
            if _distance(self.hero, enemy) <= limit
        ]


def _distance_sq(a, b):
    dx = a.x - b.x
    dy = a.y - b.y
    return dx * dx + dy * dy


def _distance(a, b):
    return math.sqrt(_distance_sq(a, b))
