"""Night Survivors: window, drawing and input.

Run it with:  python3 main.py
Walk with the mouse (or a finger). P pauses. Click or tap at the end
to play again.

This file only loads finished files from assets/ and sounds/ (that
comes in later steps). It must not import PIL, wave, make_assets or
make_sounds, because those do not work in a web browser.
"""

import asyncio
import math
from pathlib import Path

import pygame

import rules

DATA = rules.load_data()
WIDTH = DATA["window"]["width"]
HEIGHT = DATA["window"]["height"]
FPS = 60
ASSETS = Path(__file__).resolve().parent / "assets"

BACKDROP = (20, 24, 33)
SPARK_COLOUR = (255, 232, 110)
SPARK_EDGE = (70, 50, 15)
HP_BACK = (52, 22, 28)
HP_RED = (225, 65, 80)
TEXT = (235, 240, 250)
TEXT_SOFT = (150, 160, 178)
HINT_COLOUR = (70, 58, 45)
OVERLAY = (0, 0, 0, 175)


def load_image(name):
    """Load a finished picture from assets/ (made by make_assets.py)."""
    return pygame.image.load(str(ASSETS / name)).convert_alpha()


def make_fonts():
    """Three text sizes. Font(None, size) uses pygame's built-in font."""
    return pygame.font.Font(None, 72), pygame.font.Font(None, 34), pygame.font.Font(None, 22)


def draw_text(screen, text, font, colour, centre):
    image = font.render(text, True, colour)
    screen.blit(image, image.get_rect(center=centre))


def format_time(seconds):
    whole = int(seconds)
    return "{}:{:02d}".format(whole // 60, whole % 60)


def camera_for(hero):
    """The world point shown in the top-left corner of the window."""
    return hero.x - WIDTH / 2.0, hero.y - HEIGHT / 2.0


def draw_floor(screen, camera_x, camera_y, floor_image):
    """The floor is one tile repeated forever, so the map has no edges."""
    tile = floor_image.get_width()
    cam_x = int(camera_x)
    cam_y = int(camera_y)
    first_x = cam_x // tile - 1
    first_y = cam_y // tile - 1
    last_x = (cam_x + WIDTH) // tile + 1
    last_y = (cam_y + HEIGHT) // tile + 1
    for ty in range(first_y, last_y + 1):
        for tx in range(first_x, last_x + 1):
            screen.blit(floor_image, (tx * tile - cam_x, ty * tile - cam_y))


def draw_spark(screen, spark, camera_x, camera_y):
    x = int(spark.x - camera_x)
    y = int(spark.y - camera_y)
    radius = int(spark.radius)
    pygame.draw.circle(screen, SPARK_EDGE, (x, y), radius + 2)
    pygame.draw.circle(screen, SPARK_COLOUR, (x, y), radius)


def draw_enemy(screen, enemy, camera_x, camera_y, image):
    x = int(enemy.x - camera_x)
    y = int(enemy.y - camera_y)
    screen.blit(image, image.get_rect(center=(x, y)))


def draw_hero(screen, hero, camera_x, camera_y, image):
    x = int(hero.x - camera_x)
    y = int(hero.y - camera_y)
    screen.blit(image, image.get_rect(center=(x, y)))


def draw_hud(screen, game, font_small):
    # A dark see-through panel, so the white text is easy to read on any floor.
    panel = pygame.Surface((218, 54), pygame.SRCALPHA)
    pygame.draw.rect(panel, (0, 0, 0, 110), panel.get_rect(), border_radius=10)
    screen.blit(panel, (6, 6))

    # HP bar, top left
    bar = pygame.Rect(14, 14, 190, 16)
    pygame.draw.rect(screen, HP_BACK, bar, border_radius=8)
    part = max(0.0, min(1.0, game.hero.hp / game.hero.max_hp))
    if part > 0:
        fill = pygame.Rect(bar.x, bar.y, int(bar.width * part), bar.height)
        pygame.draw.rect(screen, HP_RED, fill, border_radius=8)
    pygame.draw.rect(screen, TEXT_SOFT, bar, 1, border_radius=8)
    label = font_small.render("HP {} / {}".format(game.hero.hp, game.hero.max_hp), True, TEXT)
    screen.blit(label, (bar.x + 6, bar.bottom + 5))

    hint = font_small.render("P = pause", True, HINT_COLOUR)
    screen.blit(hint, hint.get_rect(bottomright=(WIDTH - 12, HEIGHT - 10)))


def draw_game_over(screen, game, fonts):
    font_big, font_mid, font_small = fonts
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill(OVERLAY)
    screen.blit(overlay, (0, 0))
    draw_text(screen, "GAME OVER", font_big, HP_RED, (WIDTH // 2, HEIGHT // 2 - 110))
    draw_text(screen, "Time  " + format_time(game.time), font_mid, TEXT, (WIDTH // 2, HEIGHT // 2 - 20))
    draw_text(screen, "Kills  {}".format(game.kills), font_mid, TEXT, (WIDTH // 2, HEIGHT // 2 + 20))
    draw_text(
        screen,
        "Click or tap to play again",
        font_small,
        TEXT_SOFT,
        (WIDTH // 2, HEIGHT // 2 + 90),
    )


def draw_paused(screen, fonts):
    font_big, font_mid, _ = fonts
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 140))
    screen.blit(overlay, (0, 0))
    draw_text(screen, "PAUSED", font_big, TEXT, (WIDTH // 2, HEIGHT // 2 - 20))
    draw_text(screen, "Press P to continue", font_mid, TEXT_SOFT, (WIDTH // 2, HEIGHT // 2 + 30))


async def main(game=None):
    pygame.init()
    pygame.display.set_caption("Night Survivors")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    fonts = make_fonts()

    # Pictures from assets/ (made by make_assets.py, 3x bigger, no blurring).
    tile_size = DATA["floor"]["tile_size"]
    floor_image = pygame.transform.scale(load_image("floor.png"), (tile_size, tile_size))
    hero_image = load_image("hero.png")
    bat_image = load_image("bat.png")

    if game is None:
        game = rules.Game()

    paused = False
    running = True
    mouse_pos = None  # the last place the mouse was seen (screen pixels)
    use_mouse = True  # a finger turns this off: on a phone we follow the finger
    touch_pos = None  # (screen x, screen y) while a finger touches
    touch_finger = None
    accumulator = 0.0

    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.1)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    paused = not paused
                elif event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEMOTION:
                mouse_pos = event.pos

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    mouse_pos = event.pos
                    if game.state == "game_over":
                        game.reset()
                        paused = False
                        accumulator = 0.0

            elif event.type == pygame.FINGERDOWN:
                use_mouse = False
                if game.state == "game_over":
                    game.reset()
                    paused = False
                    accumulator = 0.0
                touch_finger = event.finger_id
                touch_pos = (event.x * WIDTH, event.y * HEIGHT)

            elif event.type == pygame.FINGERMOTION:
                if touch_finger is None or event.finger_id == touch_finger:
                    touch_finger = event.finger_id
                    touch_pos = (event.x * WIDTH, event.y * HEIGHT)

            elif event.type == pygame.FINGERUP:
                if event.finger_id == touch_finger:
                    touch_finger = None
                    touch_pos = None

        # Where is the hero trying to walk? The hero is always drawn in
        # the middle of the screen (the camera follows him), so we measure
        # the pointer from the middle of the screen.
        pointer = None
        if touch_pos is not None:
            pointer = touch_pos
        elif use_mouse and mouse_pos is not None:
            pointer = mouse_pos

        move = (0.0, 0.0)
        if pointer is not None and game.state == "playing" and not paused:
            dx = pointer[0] - WIDTH / 2.0
            dy = pointer[1] - HEIGHT / 2.0
            distance = math.hypot(dx, dy)
            # The hero keeps walking while the pointer is far enough away.
            if distance > DATA["controls"]["stop_distance"]:
                move = (dx / distance, dy / distance)

        # Fixed time step: the rules always move in steps of 1/60 s.
        if paused or game.state != "playing":
            accumulator = 0.0
        else:
            accumulator += dt
            while accumulator >= rules.DT and game.state == "playing":
                game.step(rules.DT, move)
                accumulator -= rules.DT

        camera_x, camera_y = camera_for(game.hero)
        screen.fill(BACKDROP)
        draw_floor(screen, camera_x, camera_y, floor_image)

        for spark in game.sparks:
            draw_spark(screen, spark, camera_x, camera_y)

        for enemy in game.enemies:
            if abs(enemy.x - game.hero.x) < WIDTH / 2 + 40 and abs(enemy.y - game.hero.y) < HEIGHT / 2 + 40:
                draw_enemy(screen, enemy, camera_x, camera_y, bat_image)

        draw_hero(screen, game.hero, camera_x, camera_y, hero_image)
        draw_hud(screen, game, fonts[2])

        if game.state == "game_over":
            draw_game_over(screen, game, fonts)
        elif paused:
            draw_paused(screen, fonts)

        pygame.display.flip()
        await asyncio.sleep(0)  # give the browser a turn (pygbag)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
